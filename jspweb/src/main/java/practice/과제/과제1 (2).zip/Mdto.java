package practice.과제.과제1;

public class Mdto {
	private int no;
	private String img;					// 사원이미지
	private String name;				// 사원이름
	private String jobgrade;			// 직급
	private String type; 				// 고용형태
	private String indate;				// 입사일
	private String outdate;				// 퇴사일
	private String outreason;			// 퇴사사유
	private String part;				// 부서이름
	private int pno;					// 부서번호
    
    public Mdto() {}

	public Mdto(int no, String img, String name, String jobgrade, String type, String indate, String outdate,
			String outreason, int pno) {
		super();
		this.no = no;
		this.img = img;
		this.name = name;
		this.jobgrade = jobgrade;
		this.type = type;
		this.indate = indate;
		this.outdate = outdate;
		this.outreason = outreason;
		this.pno = pno;
	}
	public Mdto(int no, String img, String name, String jobgrade, String type, String indate, String outdate,
			String outreason, String part, int pno) {
		super();
		this.no = no;
		this.img = img;
		this.name = name;
		this.jobgrade = jobgrade;
		this.type = type;
		this.indate = indate;
		this.outdate = outdate;
		this.outreason = outreason;
		this.part = part;
		this.pno = pno;
	}

	public String getPart() {
		return part;
	}

	public void setPart(String part) {
		this.part = part;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJobgrade() {
		return jobgrade;
	}

	public void setJobgrade(String jobgrade) {
		this.jobgrade = jobgrade;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIndate() {
		return indate;
	}

	public void setIndate(String indate) {
		this.indate = indate;
	}

	public String getOutdate() {
		return outdate;
	}

	public void setOutdate(String outdate) {
		this.outdate = outdate;
	}

	public String getOutreason() {
		return outreason;
	}

	public void setOutreason(String outreason) {
		this.outreason = outreason;
	}

	public int getPno() {
		return pno;
	}

	public void setPno(int pno) {
		this.pno = pno;
	}

	@Override
	public String toString() {
		return "Mdto [no=" + no + ", img=" + img + ", name=" + name + ", jobgrade=" + jobgrade + ", type=" + type
				+ ", indate=" + indate + ", outdate=" + outdate + ", outreason=" + outreason + ", pno=" + pno + "]";
	}
    
	

}
