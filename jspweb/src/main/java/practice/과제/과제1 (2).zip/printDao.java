package practice.과제.과제1;

import java.util.ArrayList;

public class printDao extends Dao{
	
	private static printDao dao = new printDao();
	private printDao() {}
	public static printDao getInstance() {return dao;}
	
	// 출력 메소드
	public ArrayList<Mdto> print(){
		ArrayList<Mdto> list = new ArrayList<>();
		String sql = "select no,img,name,jobgrade,type,indate,outdate,outreason,partname,p.pno from employee e,part p where e.pno=p.pno;";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				Mdto mdto = new Mdto(rs.getInt(1), rs.getString(2), 
						rs.getString(3), rs.getString(4), 
						rs.getString(5), rs.getString(6), 
						rs.getString(7), rs.getString(8),
						rs.getString(9), rs.getInt(10));
				list.add(mdto);
				System.out.println("mdto : "+ mdto);
			} // while e
		} catch (Exception e) {System.out.println("print DB에러 : "+ e);}
		return list;
	} // print e
	
	public boolean onDelete(int no) {
		String sql = "delete from employee where no=?; ";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, no);
			int count = ps.executeUpdate();
			if(count==1) {return true;}
		} catch (Exception e) {System.out.println("onDelete에러 : "+ e);}
		return false;
	}
	
	public boolean onUpdate(String img, String name,String type, String part, int no) {
		String sql = "update employee set img=?, name=?, type=?,part=? where no=?; ";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, img);
			ps.setString(2, name);
			ps.setString(3, type);
			ps.setString(4, part);
			ps.setInt(5, no);
			int count = ps.executeUpdate(); // 수정된 레코드 수 반환
			if(count==1) {return true;}
		} catch (Exception e) {System.out.println("print DB에러 : "+ e);}
		return false;
	}
}
