package practice.과제.과제1;

public class Pdto {
	
	private int pno;				// 부서번호
	private String partname;		// 부서명
	private String manager; 		//관리자
	
    public Pdto() {}

	public Pdto(int pno, String partname, String manager) {
		super();
		this.pno = pno;
		this.partname = partname;
		this.manager = manager;
	}

	public int getPno() {
		return pno;
	}

	public void setPno(int pno) {
		this.pno = pno;
	}

	public String getPartname() {
		return partname;
	}

	public void setPartname(String partname) {
		this.partname = partname;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	@Override
	public String toString() {
		return "Pdto [pno=" + pno + ", partname=" + partname + ", manager=" + manager + "]";
	}
    
    

}
