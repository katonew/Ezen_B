package practice.과제.과제1;

import java.util.ArrayList;

public class printDao extends Dao{
	
	private static printDao dao = new printDao();
	private printDao() {}
	public static printDao getInstance() {return dao;}
	
	// 출력 메소드
	public ArrayList<Mdto> print(){
		ArrayList<Mdto> list = new ArrayList<>();
		String sql = "select *from employee;";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				Mdto mdto = new Mdto(rs.getInt(1), rs.getString(2), 
						rs.getString(3), rs.getString(4), 
						rs.getString(5), rs.getString(6), 
						rs.getString(7), rs.getString(8),
						rs.getInt(9));
				list.add(mdto);
				System.out.println("mdto : "+ mdto);
			} // while e
		} catch (Exception e) {System.out.println("print DB에러 : "+ e);}
		return list;
	} // print e
	
	public boolean onDelete(int no) {
		String sql = "delete from employee where no=?; ";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, no);
			int count = ps.executeUpdate();
			if(count==1) {return true;}
		} catch (Exception e) {System.out.println("onDelete에러 : "+ e);}
		return false;
	}
	
	public boolean onUpdate(int no) {
		String sql = "delete from employee where no=?; ";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, no);
			int count = ps.executeUpdate(); // 수정된 레코드 수 반환
			if(count==1) {return true;}
		} catch (Exception e) {System.out.println("print DB에러 : "+ e);}
		return false;
	}
}
